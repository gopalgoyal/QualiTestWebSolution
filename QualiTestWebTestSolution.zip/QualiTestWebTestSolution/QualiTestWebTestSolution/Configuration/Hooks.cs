﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.MarkupUtils;
using AventStack.ExtentReports.Reporter;
using System;
using System.IO;
using TechTalk.SpecFlow;

namespace QualiTestWebTestSolution.Configuration
{
    
    [Binding]
    public sealed class Hooks : Base
    {

        [BeforeTestRun]
        public static void InitializeReport()
        {
            //empty the screenshot folder and log fle before run
            //emptyFolder(pth + "Screenshots");
            File.Delete(@Path.GetFullPath(Path.Combine(pth, "..\\..\\")) + "TestResults\\logs.txt");
            //Set stop execute property to NO if it was changed by manually or due to previos failures
            setProperty("StopExecute", "NO");
            //Launch the browser
            Browser();
        }

        [AfterTestRun]
        public static void AfterTest()
        {
            //Create extent report
            createExtentReport();
            Extent.Flush();

            //Close browsers and kill all drivers
            dr.Quit();
            killdriver(br);
        }

        [BeforeFeature]
        public static void BeforeFeature()
        {
            Console.WriteLine(FeatureContext.Current.FeatureInfo.Title);
            FeatureName = Extent.CreateTest<Feature>(FeatureContext.Current.FeatureInfo.Title + ": " + FeatureContext.Current.FeatureInfo.Description);
            setProperty("StopFeature", "NO");
        }

        [AfterFeature]
        public static void AfterFeature()
        {
            //After feature stuffs
        }


        [BeforeScenario]
        public static void BeforeScenario()
        {
            dr.Manage().Window.Maximize();
            //Below code is to check whether to continue execution or current feature based on previous scenario status
            if (getProperty("StopExecute").Equals("YES")) LogIt("Test execution has been stopped", logTyp.Skip);
            if (getProperty("StopFeature").Equals("YES")) LogIt("Feature execution stopped due to previous fatal error", logTyp.Skip);
            scenarioName = FeatureName.CreateNode<Scenario>(ScenarioContext.Current.ScenarioInfo.Title);
        }

        [AfterScenario]
        public static void AfterScenario()
        {
            //clear reset browser if required
            dr.Manage().Cookies.DeleteAllCookies();

        }

        [BeforeStep]
        public void BeforeStep()
        {
            var StepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();
            if (StepType == "Given")
                logg = scenarioName.CreateNode<Given>("₲ : " + ScenarioStepContext.Current.StepInfo.Text);
            else if (StepType == "When")
                logg = scenarioName.CreateNode<When>("₩ : " + ScenarioStepContext.Current.StepInfo.Text);
            else if (StepType == "Then")
                logg = scenarioName.CreateNode<Then>("₸ : " + ScenarioStepContext.Current.StepInfo.Text);
            else
                logg = scenarioName.CreateNode<And>("₳ : " + ScenarioStepContext.Current.StepInfo.Text);
        }

        [AfterStep]
        public void AfterStep()
        {
            //After step stuffs
        }

        public static void emptyFolder(string pth)
        {
            bool del = true;
            System.IO.DirectoryInfo di = new DirectoryInfo(pth);
            foreach (FileInfo file in di.GetFiles())
                try
                {
                    file.Delete();
                }
                catch (Exception e) { LogIt("Couldn't delete file: " + file.FullName, logTyp.Warn); del = false; }
            if (del == true) LogIt("Deleted all files inside screenshots ", logTyp.Console);
        }
        public static void createExtentReport()
        {
            string Report = "TestReport_" + System.DateTime.Now.ToString("yyyy-MM-dd_") + System.DateTime.Now.ToString("HH") + "h" + System.DateTime.Now.ToString("mm") + "m";
            string rPath = Path.GetFullPath(Path.Combine(pth, "..\\..\\")) + "TestResults\\" + Report + ".html";
            var HtmlReporter = new ExtentV3HtmlReporter(@rPath);
            HtmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            HtmlReporter.Config.ReportName = "Test Automation Report: " + appVer + " _________________________________________________________ Browser: " + brNm + " ( " + brVer + " ) _________________________________________________________ Reported by: " + Environment.UserName;
            Extent.AttachReporter(HtmlReporter);
        }

    }
}


