﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QualiTestWebTestSolution.Locators
{
    class OrderPlacementLocators
    {
        public string tShirt = "//*[@id='block_top_menu']/ul/li/a[(text() ='T-shirts')]";
        public string addCart = "//a[@title='Add to cart']";
        public string hoverProduct = "//a[@class='product_img_link']";
        public string proceedCheckout = "//span[contains(text(),'Proceed to checkout')]";
        public string summCheckout = "//*[@id='center_column']//a[@title='Proceed to checkout']";
        public string signinbtn = "//a[contains(text(),'Sign in')]";
        public string userName = "email";
        public string passWord = "passwd";
        public string signIn = "SubmitLogin";

        public string addrCheckout = "//*[@name='processAddress']";
        public string shipHeading = "//*[@id='carrier_area']/h1[text() = 'Shipping']";
        public string shipCheckout = "//button[@name='processCarrier']";
        public string terms = "//*[@id='form']/div/p[2]/label";
        public string paymentHeading = "//*[@id='center_column']/h1[text() = 'Please choose your payment method']";
        public string paybyCheck = "//a[contains(text(),'Pay by check')]";
        public string paybyWire = "//a[@title ='Pay by bank wire']";
        public string confOrder = "//*[@id='cart_navigation']/button[@type ='submit']";
        public string successMsg = "//*[@id='center_column']/div";
        public string custAcc = "//a[@class ='account']";
        public string accHeading = "//*[@id='center_column']/h1[text() = 'My account']";
        public string orderHistory = "//a[@title ='Orders']";
        public string orderHistoryHeading = "//*[@id='center_column']/h1[text() = 'Order history']";
        public string orderHistoryTbl = "order-list";

        public string personalInfo = "//span[contains(text(), 'My personal information')]";
        public string firstName = "//input[@id = 'firstname']";
        public string confPassWord = "//input[@id = 'old_passwd']";
        public string saveBtn = "//button[@name = 'submitIdentity']";
        public string myAccount = "//a[contains(text(),'My account')][1]";
        public string firstrefNum = "//table[@id='order-list']//tr[1]/td[1]/a";


    }
}
